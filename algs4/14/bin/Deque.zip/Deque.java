import java.util.Iterator;
import java.util.Spliterator;
import java.util.function.Consumer;


public class Deque<Item> implements Iterable<Item> {

	public Deque() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Iterator<Item> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void forEach(Consumer<? super Item> action) {
		// TODO Auto-generated method stub

	}

	@Override
	public Spliterator<Item> spliterator() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
